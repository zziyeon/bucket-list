const theme = {
    background: '#101010',
    itemBackground: '#313131',
    title: 'white',
    input: '#1b79de',
    main: '#1b79de',
    text: '#cfcfcf',
    done: '#616161'
}

export default theme;